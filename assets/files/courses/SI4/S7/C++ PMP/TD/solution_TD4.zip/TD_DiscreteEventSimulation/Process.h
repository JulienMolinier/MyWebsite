/***
*  do What The F**k you want to Public License
*  Version 1.0, March 2000
*  Copyright (C) 2000 Banlu Kemiyatorn (d).
*  136 Nives 7 Jangwattana 14 Laksi Bangkok
*  Everyone is permitted to copy and distribute verbatim copies
*  of this license document, but changing it is not allowed.
*
*  Ok, the purpose of this license is simple
*  and you just
*
*  DO WHAT THE F**K YOU WANT TO.
*
* @author Julien Deantoni
* @date 11/14/19
**/

#ifndef TD_SIMULATION_PROCESS_H
#define TD_SIMULATION_PROCESS_H


#include <functional>

class Simulation;

class Process {

public:
    Simulation& simu;
    std::function<void(unsigned int)> behavior;
    unsigned int firstStart = 0;
    int period = -1;

    /**
     * Simulation constructor
     *
     * @param s: the simulation
     * @param f: the function representing the behavior of the process
     * @param firstStart: the date of the first start of the process, default 0
     * @param period: the period at which the process executes, -1 means non periodic, default -1
     */
    Process(Simulation& s, std::function<void(unsigned int)> f, unsigned int firstStart = 0, int period = -1);

    void start();

};


#endif //TD_SIMULATION_PROCESS_H

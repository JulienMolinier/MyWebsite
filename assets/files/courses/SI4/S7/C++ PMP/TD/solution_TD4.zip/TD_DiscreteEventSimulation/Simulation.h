/***
*  do What The F**k you want to Public License
*  Version 1.0, March 2000
*  Copyright (C) 2000 Banlu Kemiyatorn (d).
*  136 Nives 7 Jangwattana 14 Laksi Bangkok
*  Everyone is permitted to copy and distribute verbatim copies
*  of this license document, but changing it is not allowed.
*
*  Ok, the purpose of this license is simple
*  and you just
*
*  DO WHAT THE F**K YOU WANT TO.
*
* @author Julien Deantoni
* @date 11/14/19
**/

#ifndef TD_SIMULATION_SIMULATION_H
#define TD_SIMULATION_SIMULATION_H

#include <queue>
#include "Process.h"
#include "Event.h"

class Simulation {
public:
    void run();

    void scheduleEvent(Event newEvent); //use copy to allow initialization list in call like in Simulation.cpp::run()
    void registerProcess(Process& p);

    unsigned int getCurrentTime();


private:
    std::vector<Process> ownedProcesses;
    std::priority_queue<Event, std::vector<Event>, std::greater<Event>> eventQueue;
    unsigned int currentTime = 0;
};


#endif //TD_SIMULATION_SIMULATION_H

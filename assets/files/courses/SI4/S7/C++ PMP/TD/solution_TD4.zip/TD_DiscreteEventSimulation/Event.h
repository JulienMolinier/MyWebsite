/***
*  do What The F**k you want to Public License
*  Version 1.0, March 2000
*  Copyright (C) 2000 Banlu Kemiyatorn (d).
*  136 Nives 7 Jangwattana 14 Laksi Bangkok
*  Everyone is permitted to copy and distribute verbatim copies
*  of this license document, but changing it is not allowed.
*
*  Ok, the purpose of this license is simple
*  and you just
*
*  DO WHAT THE F**K YOU WANT TO.
*
* @author Julien Deantoni
* @date 11/14/19
**/

#ifndef TD_SIMULATION_EVENT_H
#define TD_SIMULATION_EVENT_H

#include <functional>

class Process;

class Event {

public:
    Process* process = nullptr; //reference would be better but it conflicts with the (internal) use of a priority queue since operator=(Event&&) is used
    unsigned int startTime;

    Event(unsigned int t, Process& p);

    void processEvent();

    friend bool operator>(const Event& l, const Event& r);
};

#endif //TD_SIMULATION_EVENT_H

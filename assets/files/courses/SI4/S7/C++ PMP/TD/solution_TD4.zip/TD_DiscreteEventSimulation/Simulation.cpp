/***
*  do What The F**k you want to Public License
*  Version 1.0, March 2000
*  Copyright (C) 2000 Banlu Kemiyatorn (d).
*  136 Nives 7 Jangwattana 14 Laksi Bangkok
*  Everyone is permitted to copy and distribute verbatim copies
*  of this license document, but changing it is not allowed.
*
*  Ok, the purpose of this license is simple
*  and you just
*
*  DO WHAT THE F**K YOU WANT TO.
*
* @author Julien Deantoni
* @date 11/14/19
**/

#include <iostream>
#include <chrono>
#include <thread>
#include "Simulation.h"


void Simulation::scheduleEvent(Event newEvent) {
    eventQueue.push(newEvent);
}

void Simulation::run() {

    for (Process& p: ownedProcesses) {
        p.start();
    }


    while (!eventQueue.empty()) {

        Event nextEvent = eventQueue.top();
        eventQueue.pop();
        std::this_thread::sleep_for(std::chrono::seconds(nextEvent.startTime - currentTime));
        currentTime = nextEvent.startTime;
        std::cout << "at " << currentTime << ':';
        nextEvent.processEvent();
        if (nextEvent.process->period != -1) {
            this->scheduleEvent({currentTime + nextEvent.process->period, *(nextEvent.process)});
        }
    }
}

unsigned int Simulation::getCurrentTime() {
    return currentTime;
}

void Simulation::registerProcess(Process& p) {
    ownedProcesses.push_back(p);
}

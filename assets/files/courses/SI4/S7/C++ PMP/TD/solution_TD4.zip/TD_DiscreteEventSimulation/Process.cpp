/***
*  do What The F**k you want to Public License
*  Version 1.0, March 2000
*  Copyright (C) 2000 Banlu Kemiyatorn (d).
*  136 Nives 7 Jangwattana 14 Laksi Bangkok
*  Everyone is permitted to copy and distribute verbatim copies
*  of this license document, but changing it is not allowed.
*
*  Ok, the purpose of this license is simple
*  and you just
*
*  DO WHAT THE F**K YOU WANT TO.
*
* @author Julien Deantoni
* @date 11/14/19
**/

#include "Process.h"
#include "Simulation.h"

Process::Process(Simulation& s, std::function<void(unsigned int)> f, unsigned int firstStart, int period)
        : simu(s), behavior(f), firstStart(firstStart), period(period) {}

void Process::start() {
    simu.scheduleEvent({firstStart, (*this)});
}

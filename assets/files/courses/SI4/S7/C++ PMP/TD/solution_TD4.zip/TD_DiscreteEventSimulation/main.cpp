/***
*  do What The F**k you want to Public License
*  Version 1.0, March 2000
*  Copyright (C) 2000 Banlu Kemiyatorn (d).
*  136 Nives 7 Jangwattana 14 Laksi Bangkok
*  Everyone is permitted to copy and distribute verbatim copies
*  of this license document, but changing it is not allowed.
*
*  Ok, the purpose of this license is simple
*  and you just
*
*  DO WHAT THE F**K YOU WANT TO.
*
* @author Julien Deantoni
* @date 11/14/19
**/

#include <iostream>
#include "Simulation.h"
#include "Process.h"
#include <math.h>


void f(unsigned int t) {
    std::cout << "single exec ! " << std::endl;
}

void g(unsigned int t) {
    std::cout << "sin(" << t << ") = " <<  sin(t) << std::endl;
}

void h(unsigned int t) {
    std::cout << "cos(" << t << ") = " << cos(t) << std::endl;
}

int main() {
    Simulation s;
    Process p1 = {s, f, 3};
    Process p2 = {s, g, 2, 1};
    Process p3 = {s, h, 1, 6};
    s.registerProcess(p1);
    s.registerProcess(p2);
    s.registerProcess(p3);
    s.run();
    return 0;
}